A complete Login Registration system using HTML5,CSS,Bootstrap-4,JavaScript for front-end and for back-end PHP framework Laravel,MySql database with some key functionalities like,


i)User Registration & Login process using built-in Authentication of Laravel,

ii)User can update or delete data when he's in logged in mood.He can also change the password with logged in mood.With and Without logged in User can also view the details.